/*
Business rules:
Give movie discount to chidren under 12 and senior over 65 for the G-rated movies.

Use AND (&&) and OR (||) logical operators  () 
Pay attention to the execution rules
 */

using System;
using static System.Console;
class MovieDiscount
{
    static void Main()
    {
        
    }
}
